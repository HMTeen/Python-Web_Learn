const url = 'http://192.168.160.245:8080'

export default{
    url
}
